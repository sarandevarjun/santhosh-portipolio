# TVK Submit Page QR Code

## Page URL (after deployment):
https://tvk-thogaimalai-east.vercel.app/submit

## Generate QR Code:
1. Go to: https://qr-code-generator.com
2. Paste URL: https://tvk-thogaimalai-east.vercel.app/submit
3. Download as PNG (high resolution)
4. Add to poster design

## WhatsApp number to update in submit-page.js:
const SANTHOSH_PHONE = '919876543210'; // Replace with real number
// Format: 91 + 10 digit number (no spaces)
// Example: 919876543210 for 9876543210

## Poster text suggestion:
┌────────────────────────────────┐
│    தமிழக வெற்றிக் கழகம்       │
│   தோகைமலை கிழக்கு ஒன்றியம்   │
│                                │
│   உங்கள் பிரச்சினையை          │
│   நேரடியாக பதிவு செய்யுங்கள் │
│                                │
│         [QR CODE]              │
│                                │
│  📱 QR Scan செய்து            │
│  உங்கள் பிரச்சினையை          │
│  பதிவு செய்யுங்கள்            │
│                                │
│  24 மணி நேரத்தில் தீர்வு!    │
└────────────────────────────────┘

## navLinks update needed in data/site-content.js:
Add: { label: "பிரச்சினை பதிவு", labelEn: "Submit Issue", href: "/submit" }
