// Replace navLinks in data/site-content.js with:
export const navLinks = [
  { label: "முகப்பு",       href: "/" },
  { label: "எங்களை பற்றி",  href: "/about" },
  { label: "நிகழ்வுகள்",    href: "/events" },
  { label: "நல திட்டங்கள்", href: "/schemes" },
  { label: "தொடர்புக்கு",   href: "/contact" },
];
